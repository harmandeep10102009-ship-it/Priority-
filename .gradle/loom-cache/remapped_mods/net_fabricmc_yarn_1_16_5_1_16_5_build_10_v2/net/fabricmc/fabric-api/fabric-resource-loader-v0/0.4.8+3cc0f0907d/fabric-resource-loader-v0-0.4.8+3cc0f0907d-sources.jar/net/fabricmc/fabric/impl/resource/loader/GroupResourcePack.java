/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.loader;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.resource.ModResourcePack;
import net.fabricmc.fabric.mixin.resource.loader.NamespaceResourceManagerAccessor;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceImpl;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

/**
 * Represents a group resource pack, holds multiple resource packs as one.
 */
public abstract class GroupResourcePack implements ResourcePack {
	protected final ResourceType type;
	protected final List<ModResourcePack> packs;
	protected final Map<String, List<ModResourcePack>> namespacedPacks = new Object2ObjectOpenHashMap<>();

	public GroupResourcePack(ResourceType type, List<ModResourcePack> packs) {
		this.type = type;
		this.packs = packs;
		this.packs.forEach(pack -> pack.getNamespaces(this.type)
				.forEach(namespace -> this.namespacedPacks.computeIfAbsent(namespace, value -> new ArrayList<>())
						.add(pack)));
	}

	@Override
	public InputStream method_14405(ResourceType type, class_2960 ) throws IOException {
		List<ModResourcePack> packs = this.namespacedPacks.get(.method_12836());

		if (packs != null) {
			for (int i = packs.size() - 1; i >= 0; i--) {
				class_3262 pack = packs.get(i);

				if (pack.method_14411(type, )) {
					return pack.method_14405(type, );
				}
			}
		}

		throw new class_3266(null,
				String.format("%s/%s/%s", type.method_14413(), .method_12836(), .method_12832()));
	}

	@Override
	public Collection<Identifier> method_14408(ResourceType type, String , String , int , Predicate<String> ) {
		List<ModResourcePack> packs = this.namespacedPacks.get();

		if (packs == null) {
			return Collections.emptyList();
		}

		Set<class_2960> resources = new HashSet<>();

		for (int i = packs.size() - 1; i >= 0; i--) {
			class_3262 pack = packs.get(i);
			Collection<class_2960> modResources = pack.method_14408(type, , , , );

			resources.addAll(modResources);
		}

		return resources;
	}

	@Override
	public boolean method_14411(ResourceType type, class_2960 ) {
		List<ModResourcePack> packs = this.namespacedPacks.get(.method_12836());

		if (packs == null) {
			return false;
		}

		for (int i = packs.size() - 1; i >= 0; i--) {
			class_3262 pack = packs.get(i);

			if (pack.method_14411(type, )) {
				return true;
			}
		}

		return false;
	}

	@Override
	public Set<String> getNamespaces(ResourceType type) {
		return this.namespacedPacks.keySet();
	}

	public void appendResources(NamespaceResourceManagerAccessor manager, Identifier id, List<Resource> resources) throws IOException {
		List<ModResourcePack> packs = this.namespacedPacks.get(id.getNamespace());

		if (packs == null) {
			return;
		}

		Identifier metadataId = NamespaceResourceManagerAccessor.fabric$accessor_getMetadataPath(id);

		for (ModResourcePack pack : packs) {
			if (pack.contains(manager.getType(), id)) {
				InputStream metadataInputStream = pack.contains(manager.getType(), metadataId) ? manager.fabric$accessor_open(metadataId, pack) : null;
				resources.add(new ResourceImpl(pack.getName(), id, manager.fabric$accessor_open(id, pack), metadataInputStream));
			}
		}
	}

	public String getFullName() {
		return this.getName() + " (" + this.packs.stream().map(ResourcePack::getName).collect(Collectors.joining(", ")) + ")";
	}

	@Override
	public void close() {
		this.packs.forEach(ResourcePack::close);
	}
}
