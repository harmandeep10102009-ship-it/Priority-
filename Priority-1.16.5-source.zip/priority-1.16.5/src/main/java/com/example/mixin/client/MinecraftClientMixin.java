package com.example.mixin.client;

import com.example.config.HotbarPriorityConfig;
import me.shedaniel.autoconfig.AutoConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    private int winningKeyIndex = -1;
    private int highestPriority = Integer.MAX_VALUE;
    private boolean checkedThisTick = false;

    @Redirect(
        method = "handleInputEvents",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/options/KeyBinding;wasPressed()Z"
        )
    )
    private boolean redirectWasPressed(KeyBinding keyBinding) {
        MinecraftClient client = (MinecraftClient) (Object) this;

        // Check if this keybinding is one of the hotbar keys
        KeyBinding[] hotbarKeys = client.options.keysHotbar;
        int thisKeyIndex = -1;
        for (int i = 0; i < hotbarKeys.length; i++) {
            if (hotbarKeys[i] == keyBinding) {
                thisKeyIndex = i;
                break;
            }
        }

        // Not a hotbar key — behave normally
        if (thisKeyIndex == -1) {
            return keyBinding.wasPressed();
        }

        // It's a hotbar key — apply priority logic
        HotbarPriorityConfig config = AutoConfig.getConfigHolder(HotbarPriorityConfig.class).getConfig();

        if (!checkedThisTick) {
            // First hotbar key we encounter this tick — find the one with highest priority
            winningKeyIndex = -1;
            highestPriority = Integer.MAX_VALUE;

            for (int i = 0; i < hotbarKeys.length; i++) {
                if (hotbarKeys[i].isPressed()) {
                    int priority = config.getSlotPriority(i);
                    if (priority < highestPriority) {
                        highestPriority = priority;
                        winningKeyIndex = i;
                    }
                }
            }
            checkedThisTick = true;

            // Reset on next tick by scheduling a flag clear
            // We piggyback on the fact that handleInputEvents is called once per tick
        }

        // Only the winning key "was pressed"; others return false
        if (thisKeyIndex == winningKeyIndex) {
            checkedThisTick = false; // Reset for next tick after winner is consumed
            return keyBinding.wasPressed();
        } else {
            // Consume without acting
            while (keyBinding.wasPressed()) { /* drain */ }
            return false;
        }
    }
}
