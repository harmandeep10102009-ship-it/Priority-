package com.example.mixin.client;

import com.example.config.HotbarPriorityConfig;
import me.shedaniel.autoconfig.AutoConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Environment(EnvType.CLIENT)
@Mixin(class_310.class)
public class MinecraftClientMixin {

    private int winningKeyIndex = -1;
    private int highestPriority = Integer.MAX_VALUE;
    private boolean checkedThisTick = false;

    @Redirect(
        method = "handleInputEvents",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/option/KeyBinding;wasPressed()Z"
        )
    )
    private boolean redirectWasPressed(class_304 keyBinding) {
        class_310 client = (class_310) (Object) this;
        class_304[] hotbarKeys = client.field_1690.field_1852;
        int thisKeyIndex = -1;
        for (int i = 0; i < hotbarKeys.length; i++) {
            if (hotbarKeys[i] == keyBinding) {
                thisKeyIndex = i;
                break;
            }
        }
        if (thisKeyIndex == -1) {
            return keyBinding.method_1436();
        }
        HotbarPriorityConfig config = AutoConfig.getConfigHolder(HotbarPriorityConfig.class).getConfig();
        if (!checkedThisTick) {
            winningKeyIndex = -1;
            highestPriority = Integer.MAX_VALUE;
            for (int i = 0; i < hotbarKeys.length; i++) {
                if (hotbarKeys[i].method_1434()) {
                    int priority = config.getSlotPriority(i);
                    if (priority < highestPriority) {
                        highestPriority = priority;
                        winningKeyIndex = i;
                    }
                }
            }
            checkedThisTick = true;
        }
        if (thisKeyIndex == winningKeyIndex) {
            checkedThisTick = false;
            return keyBinding.method_1436();
        } else {
            while (keyBinding.method_1436()) { }
            return false;
        }
    }
}
